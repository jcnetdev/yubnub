# set SASS overrides from app config
Sass::Plugin.options[:style] = :compact