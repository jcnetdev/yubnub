ActiveSupport::CoreExtensions::Time::Conversions::DATE_FORMATS.merge!(:date => "%m/%d/%Y")
ActiveSupport::CoreExtensions::Time::Conversions::DATE_FORMATS.merge!(:use_date => "%Y-%m-%d %H:%M")