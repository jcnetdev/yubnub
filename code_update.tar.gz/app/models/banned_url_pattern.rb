class BannedUrlPattern < ActiveRecord::Base
end
