class PagesController < ApplicationController
  
end